let cartas;

function Start() {
    document.querySelector('.jogo').innerHTML = '';

    cartas = 0;
    let Quantidade;

    do {
        Quantidade = prompt('Quantidade de cartas (4 ~ 14):');
        if (!isNaN(Quantidade)) {
            cartas = Number(Quantidade);
            if (Number.isInteger(cartas)) {
                cartas = parseInt(cartas);
            }
        }
    } while ((cartas % 2 !== 0) || (cartas < 4) || (cartas > 14));

    let Deck = [
        `<img src="images/1.gif">`,
        `<img src="images/2.gif">`,
        `<img src="images/3.gif">`,
        `<img src="images/4.gif">`,
        `<img src="images/5.gif">`,
        `<img src="images/6.gif">`,
        `<img src="images/7.gif">`
    ];

    let Distribution = [];

    for (let i = 0; i != parseInt(cartas/2); i++) {
        Distribution.push(Deck[i], Deck[i]);
    }

    function comparador() { 
        return Math.random() - 0.5;
    }

    Distribution.sort(comparador);

    for (let i = 0; i < cartas; i++) {
        document.querySelector('.jogo').innerHTML += `<div class="cartas"><div class="viradaBaixo">${Distribution[i]}</div><div class="Back" onclick="Desvirar(this)"><img src="images/back.png" alt="Imagem não suportada ou indisponível"></div></div>`;
    }
}

Start();

let Tentativas = 0;
let Viradas = 0;
let parrot1;
let parrot2;
let figura1 = false;
let figura2 = false;

function Switch() {
    figura2 = false;
}

function Virar() {
    parrot1.parentNode.querySelector('.viradaCima').classList.remove('viradaCima');
    parrot1.classList.remove('viradaBaixo');

    parrot2.parentNode.querySelector('.viradaCima').classList.remove('viradaCima');
    parrot2.classList.remove('viradaBaixo');
    figura1 = false;
}

function Desvirar(x) {
    if (!figura1 && !figura2) {
        figura2 = true;

        x.parentNode.querySelector('.viradaBaixo').classList.add('viradaCima');
        x.classList.add('viradaBaixo');
        setTimeout(Switch, 500);

        Tentativas++;
        Viradas++;

        if (Tentativas%2 == 1) {
            parrot1 = x;

        } else if (x.parentNode.querySelector('.viradaCima').innerHTML != parrot1.parentNode.querySelector('.viradaCima').innerHTML) {
            Viradas -= 2;
            parrot2 = x;
            figura1 = true;
            setTimeout(Virar, 1000);
        }
    }

    setTimeout(venceu, 500);
}

function venceu() {
    if (Viradas == cartas) {
        alert(`Você ganhou em ${Tentativas / 2} jogadas!`);

        let Play = undefined;

        do {
            Play = prompt('Deseja jogar novamente? (s/n)');
        } while (!['s', 'n'].includes(Play));

        if (Play == 's') {
            Tentativas = 0;
            Viradas = 0;
            parrot1 = undefined;
            parrot2 = undefined;
            Start();
        }
    }
}